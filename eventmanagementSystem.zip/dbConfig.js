// dbConfig.js

module.exports = {
  user: "system",
  password: "Oracle_1",
  connectString: "localhost:1521/orcl", // e.g., 'localhost:1521/orcl'
};
